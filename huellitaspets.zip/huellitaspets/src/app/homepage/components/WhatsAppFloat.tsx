"use client";

import React, { useState, useEffect } from "react";
import siteConfig from "../config/site.config.json";

export default function WhatsAppFloat() {
  const [visible, setVisible] = useState(false);
  const [tooltip, setTooltip] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 1200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div
      className="fixed z-50"
      style={{
        bottom: "28px",
        right: "24px",
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0) scale(1)" : "translateY(20px) scale(0.8)",
        transition: "opacity 0.5s cubic-bezier(0.22,1,0.36,1), transform 0.5s cubic-bezier(0.22,1,0.36,1)",
      }}
    >
      {/* Tooltip */}
      {tooltip && (
        <div
          className="absolute bottom-full right-0 mb-3 whitespace-nowrap rounded-2xl font-semibold shadow-xl"
          style={{
            padding: "10px 16px",
            background: "#0e1a14",
            color: "#fff",
            fontSize: "0.8rem",
            pointerEvents: "none",
            animation: "tooltipIn 0.2s cubic-bezier(0.22,1,0.36,1) both",
          }}
        >
          💬 ¡Escribinos!
          {/* Arrow */}
          <div
            style={{
              position: "absolute",
              bottom: "-6px",
              right: "24px",
              width: 0,
              height: 0,
              borderLeft: "6px solid transparent",
              borderRight: "6px solid transparent",
              borderTop: "6px solid #0e1a14",
            }}
          />
        </div>
      )}

      {/* Button */}
      <a
        href={siteConfig.brand.whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Contactar por WhatsApp"
        className="relative flex items-center justify-center rounded-full shadow-2xl transition-transform duration-300"
        style={{
          width: "62px",
          height: "62px",
          background: "#25D366",
          boxShadow: "0 8px 32px rgba(37,211,102,0.45), 0 2px 8px rgba(0,0,0,0.15)",
        }}
        onMouseEnter={() => {
          setTooltip(true);
        }}
        onMouseLeave={() => {
          setTooltip(false);
        }}
        onMouseDown={(e) => {
          (e.currentTarget as HTMLAnchorElement).style.transform = "scale(0.93)";
        }}
        onMouseUp={(e) => {
          (e.currentTarget as HTMLAnchorElement).style.transform = "scale(1)";
        }}
      >
        {/* Pulse ring */}
        <span
          className="absolute inset-0 rounded-full"
          style={{
            animation: "waPulse 2.5s ease-out infinite",
            background: "rgba(37,211,102,0.4)",
          }}
        />

        {/* WhatsApp icon */}
        <svg
          width="30"
          height="30"
          viewBox="0 0 24 24"
          fill="#fff"
          style={{ position: "relative", zIndex: 1 }}
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
        </svg>

        {/* Red notification badge */}
        <span
          className="absolute flex items-center justify-center font-black"
          style={{
            top: "2px",
            right: "2px",
            width: "20px",
            height: "20px",
            borderRadius: "50%",
            background: "#e8523a",
            color: "#fff",
            fontSize: "0.6rem",
            border: "2px solid #fff",
            zIndex: 2,
            lineHeight: 1,
          }}
        >
          1
        </span>
      </a>

      <style>{`
        @keyframes waPulse {
          0% { transform: scale(1); opacity: 0.6; }
          70% { transform: scale(1.5); opacity: 0; }
          100% { transform: scale(1.5); opacity: 0; }
        }
        @keyframes tooltipIn {
          from { opacity: 0; transform: translateY(4px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}